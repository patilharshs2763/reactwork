import './App.css';
import UserList from './UserList';
import AddUser from './AddUser';

function App() {
  return (
    <div className="App">
      {/* <AddUser /> */}
      <UserList />
    </div>
  );
}

export default App;
